package com.abcadventure

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class Letter(val upper: String, val lower: String, val word: String, val emoji: String, val sound: String)

val letters = listOf(
    Letter("A","a","Apple","🍎","aah"), Letter("B","b","Ball","⚽","buh"),
    Letter("C","c","Cat","🐱","kuh"), Letter("D","d","Dog","🐶","duh"),
    Letter("E","e","Elephant","🐘","eh"), Letter("F","f","Fish","🐟","fuh"),
    Letter("G","g","Grapes","🍇","guh"), Letter("H","h","Hat","🎩","huh"),
    Letter("I","i","Ice cream","🍦","ih"), Letter("J","j","Juice","🧃","juh"),
    Letter("K","k","Kite","🪁","kuh"), Letter("L","l","Lion","🦁","luh"),
    Letter("M","m","Monkey","🐒","muh"), Letter("N","n","Nest","🪺","nuh"),
    Letter("O","o","Orange","🍊","oh"), Letter("P","p","Penguin","🐧","puh"),
    Letter("Q","q","Queen","👑","kwuh"), Letter("R","r","Rabbit","🐰","ruh"),
    Letter("S","s","Sun","☀️","suh"), Letter("T","t","Tiger","🐯","tuh"),
    Letter("U","u","Umbrella","☂️","uh"), Letter("V","v","Van","🚐","vuh"),
    Letter("W","w","Whale","🐳","wuh"), Letter("X","x","Xylophone","🎵","ks"),
    Letter("Y","y","Yo-yo","🪀","yuh"), Letter("Z","z","Zebra","🦓","zuh")
)

class MainActivity : ComponentActivity() {
    private lateinit var tts: TextToSpeech
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.US }
        setContent { ABCAdventure(tts) }
    }
    override fun onDestroy() { tts.stop(); tts.shutdown(); super.onDestroy() }
}

fun speak(tts: TextToSpeech, text: String) =
    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "abc")

@Composable
fun ABCAdventure(tts: TextToSpeech) {
    var screen by remember { mutableStateOf("profile") }
    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var index by remember { mutableIntStateOf(0) }
    var tapped by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(
        background = Color(0xFFFFF8EF), primary = Color(0xFF6C5CE7)
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFFFFF8EF), Color(0xFFEFF8FF)))
        )) {
            when (screen) {
                "profile" -> ProfileScreen(name, { name = it }, age, { age = it }) {
                    screen = "lesson"; speak(tts, "Let's learn the alphabet!")
                }
                "lesson" -> LessonScreen(name, letters[index], index, tapped,
                    onTap = { tapped = true; speak(tts, "Letter ${letters[index].upper}. ${letters[index].sound}. ${letters[index].upper} is for ${letters[index].word}.") },
                    onNext = {
                        tapped = false
                        if (index < 25) { index++; speak(tts, "Letter ${letters[index].upper}") }
                        else screen = "complete"
                    })
                "complete" -> CompleteScreen(name) {
                    index = 0; tapped = false; screen = "lesson"; speak(tts, "Letter A")
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(name: String, onName: (String)->Unit, age: String, onAge: (String)->Unit, start: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("🌈", fontSize = 64.sp)
        Text("ABC Adventure", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF5B4BCE))
        Text("Let’s learn and play!", fontSize = 20.sp)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(name, onName, label={Text("My name")}, singleLine=true, shape=RoundedCornerShape(18.dp), modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(age, { if(it.all(Char::isDigit) && it.length <= 2) onAge(it) }, label={Text("My age")}, singleLine=true, shape=RoundedCornerShape(18.dp), modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        Button(start, enabled=name.trim().isNotEmpty(), shape=RoundedCornerShape(22.dp), modifier=Modifier.fillMaxWidth().height(58.dp)) {
            Text("START ADVENTURE 🚀", fontSize=18.sp, fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
fun LessonScreen(childName:String, letter:Letter, index:Int, tapped:Boolean, onTap:()->Unit, onNext:()->Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(letter) { visible=false; kotlinx.coroutines.delay(100); visible=true; speakDummy() }
    val scale by animateFloatAsState(if(visible) 1f else .65f, animationSpec=spring(), label="letter")
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text("Hi, $childName! 👋", fontWeight=FontWeight.Bold)
            Text("${index+1}/26", fontWeight=FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("Tap the letter!", fontSize=21.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.size(250.dp).scale(scale).background(Brush.linearGradient(listOf(Color(0xFFFFB86C),Color(0xFFFF7AA8))),CircleShape).clickable { onTap() }, contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text(letter.upper, fontSize=110.sp, fontWeight=FontWeight.Black, color=Color.White)
                Text(letter.lower, fontSize=42.sp, fontWeight=FontWeight.Bold, color=Color.White.copy(alpha=.9f))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("${letter.upper} is for ${letter.word}", fontSize=27.sp, fontWeight=FontWeight.Bold)
        Text(letter.emoji, fontSize=68.sp)
        if (tapped) {
            Text("Great job! ⭐", fontSize=24.sp, color=Color(0xFF4E9F3D), fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button(onClick=onNext, shape=RoundedCornerShape(20.dp), modifier=Modifier.fillMaxWidth().height(56.dp)) {
                Text(if(index==25) "FINISH 🎉" else "NEXT →", fontSize=18.sp, fontWeight=FontWeight.Bold)
            }
        } else Text("Touch the letter to hear it 🔊", fontSize=17.sp)
    }
}

fun speakDummy() {}

@Composable
fun CompleteScreen(name:String, replay:()->Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("🎉", fontSize=90.sp)
        Text("Amazing, $name!", fontSize=34.sp, fontWeight=FontWeight.ExtraBold)
        Text("You learned all 26 letters!", fontSize=22.sp)
        Spacer(Modifier.height(26.dp))
        Button(replay, shape=RoundedCornerShape(20.dp), modifier=Modifier.fillMaxWidth().height(56.dp)) { Text("PLAY AGAIN", fontWeight=FontWeight.Bold) }
    }
}
