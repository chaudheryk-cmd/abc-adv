# ABC Adventure

A child-friendly Android learning game. Module 1 teaches A–Z using letter names, phonetic sounds, example words, animations, tap interaction, and Android Text-to-Speech.

## Stack
- Kotlin
- Jetpack Compose
- Material 3
- Android Text-to-Speech
- Portrait-first child UI

## Module 1 flow
Name + age → A → B → … → Z → celebration.

The alphabet content is data-driven so future learning modules can be added without duplicating screens.
